from ClasseMenu import *

menuDeOpcoes = Menu()
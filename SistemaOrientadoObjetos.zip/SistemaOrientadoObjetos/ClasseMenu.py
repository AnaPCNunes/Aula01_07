from ClasseCompra import *
from ClasseVenda import *

class Menu:
    def __init__(self):
        cadastro = Estoque()
        compra = Compra()
        venda = Venda()

        compra.entrada = cadastro
        venda.entrada = cadastro

        while True:
            entrada = input('\nEscolha a opção que deseja:\n'
                            '1 - Cadastrar Fabricantes\n'
                            '2 - Cadastrar Produtos'
                            '3 - Listar/Procurar Produtos\n'
                            '4 - Alterar Descrição do Produto\n'
                            '5 - Abastecimento de Estoque\n'
                            '6 - Retirada de Produto\n'
                            '7 - Histórico de entrada de Produtos\n'
                            '8 - Histórico de Saída de Produtos\n'
                            '0 - Sair\n')

            if entrada == '1':
                cadastro.cadastrar_fabricantes()
            elif entrada == '2':
                cadastro.cadastrar_produtos()
            elif entrada == '3':
                cadastro.listar_produtos()
            elif entrada == '4':
                cadastro.alterar_desc()
            elif entrada == '5':
                compra.comprar()
            elif entrada == '6':
                venda.vender()
            elif entrada == '7':
                compra.imprimir_abast()
            elif entrada == '8':
                venda.imprimir_retira()
            elif entrada == '0':
                break
            else:
                print('Opção Inexistente!')
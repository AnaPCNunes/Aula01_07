class Produto:
    def __init__(self, cod, desc, objeto, quant=0):
        self.cod = cod
        self.desc = desc
        self.fabri = objeto.nome
        self.quant = quant